# Parrot

Robin's Nest from *Learning PHP, MySQL, & JavaScript* by Robin Nixon


![An updated Robin's Nest](img/preview.png "An updated Robin's Nest")



A small Facebook clone based on the [mini social network final example](http://lpmj.net/) within Robin Nixon's book *Learning PHP, MySQL, & JavaScript* 



The application is to be used in conjunction with my an on going series of blog posts regarding the creation of an EC2 AWS Linux Instance, along with a LAMP web server for the purpose teaching a beginner how to run a php applicatin within the cloud, and then scale that application into a multi-tier architecture using AWS. 



The blog posts can be found at:


https://medium.com/@oreillyalan88/lamp-linux-apache-mysql-php-web-server-on-an-amazon-ec2-linux-instance-e37eb023e996

and 

https://medium.com/@oreillyalan88/migrating-a-mysql-database-from-ec2-onto-an-rds-instance-4c505867f822
