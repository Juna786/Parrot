<?php

$appname = 'Parrot';

$dbhost = '0.0.0.0';
$dbname = 'parrot';

$dbuser =  "root";
$dbpass = '**********'; //your mysql password here

